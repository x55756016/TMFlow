using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WFTools.Samples.WorkFlow")]
[assembly: AssemblyDescription("Windows Workflow Foundation Tools - Samples - WorkFlow")]
[assembly: AssemblyConfiguration("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("A1F1EDF1-D409-4e36-BFB7-F408955BE78A")]