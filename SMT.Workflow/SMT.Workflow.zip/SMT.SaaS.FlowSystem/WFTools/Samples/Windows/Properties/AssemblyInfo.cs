﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WFTools.Samples.Windows")]
[assembly: AssemblyDescription("Windows Workflow Foundation Tools - Samples - Windows")]
[assembly: AssemblyConfiguration("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("A48C9965-ADEE-41d6-9379-6A13BF8CEAE9")]