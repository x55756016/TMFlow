﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WFTools.Utilties")]
[assembly: AssemblyDescription("Windows Workflow Foundation Tools - Utility Library")]
[assembly: AssemblyConfiguration("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("49BA7016-B7E6-42cb-865D-188992E7678B")]