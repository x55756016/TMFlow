﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WFTools.Activities")]
[assembly: AssemblyDescription("Windows Workflow Foundation Tools - Activity Library")]
[assembly: AssemblyConfiguration("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("DED2C6FA-88B5-40bd-826B-088291C82048")]