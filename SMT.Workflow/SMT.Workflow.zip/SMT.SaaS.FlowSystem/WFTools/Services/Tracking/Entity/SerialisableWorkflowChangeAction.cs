namespace WFTools.Services.Tracking.Entity
{
    /// <summary>
    /// Abstract base class for all workflow change actions.
    /// </summary>
    public abstract class SerialisableWorkflowChangeAction
    {
    }
}
