using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WFTools.Services")]
[assembly: AssemblyDescription("Windows Workflow Foundation Tools - Service Library")]
[assembly: AssemblyConfiguration("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("0CFEBC4B-633C-4e2a-A0BA-A93C2EE6084B")]