namespace WFTools.Services.Common.Ado.Sql
{
    /// <summary>
    /// SQL Server specific implementation of <see cref="IAdoValueReader" />.
    /// </summary>
    public class SqlValueReader : DefaultAdoValueReader
    {
    }
}
