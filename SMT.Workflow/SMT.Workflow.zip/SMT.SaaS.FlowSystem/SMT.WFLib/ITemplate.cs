﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SMT.WFLib
{
	public interface ITemplate
	{
        FlowDataType.FlowData FlowData { get; set; }
        
	}
}
