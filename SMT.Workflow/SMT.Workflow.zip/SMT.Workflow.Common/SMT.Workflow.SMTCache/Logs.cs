﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using SMT.Foundation.Log;

namespace SMT.Workflow.SMTCache
{
    public class Logs
    {
        /// <summary>
        /// 写日志
        /// </summary>
        /// <param name="fileName">文件名如:myname</param>
        /// <param name="content">日志内容</param>
        /// <returns></returns>
        public static void WriteLog(string fileName, string content)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("------------------------------------------------------------------------------------------------------------------------------");
            sb.AppendLine("发生时间：" + DateTime.Now.ToString());
            sb.AppendLine("日志内容:" + content);
            Tracer.Debug(sb.ToString());
        }
    }
}

